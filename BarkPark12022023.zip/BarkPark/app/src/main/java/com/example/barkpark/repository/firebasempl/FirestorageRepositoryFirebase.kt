package com.example.barkpark.repository.firebasempl

import android.net.Uri
import android.util.Log
import com.example.barkpark.repository.FirestorageRepository
import com.example.barkpark.util.Resource
import com.example.barkpark.util.safeCall
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URI

class FirestorageRepositoryFirebase : FirestorageRepository {

    //val storage = Firebase.storage

    var storageRef = FirebaseStorage.getInstance().reference

    /*val storage = FirebaseStorage.getInstance()
    val storageRef = storage.getReference(fileName)*/

    override suspend fun uploadUserImage(newPic: Uri? , userId: String) = withContext(Dispatchers.IO) {
        safeCall {
            if (newPic != null) {
                Log.d("in FSRURI", newPic.toString())
            }
            var file = Uri.fromFile(File(newPic?.path.toString()))
            val pictureRef = storageRef.child("images/users/${userId}")
            var uploadTask = pictureRef.putFile(file).await()
            Resource.Success(uploadTask)
        }
    }

    override suspend fun uploadDogImage(image: String?, dogId: String) = withContext(Dispatchers.IO) {
        safeCall {
            var file = Uri.fromFile(File(image.toString()))
            val pictureRef = storageRef.child("images/dogs/${dogId}")
            var uploadTask = pictureRef.putFile(file).await()
            Resource.Success(uploadTask)
        }
    }

   /* override suspend fun downloadUserImage(userId: String): Resource<String?> = withContext(Dispatchers.IO) {
        safeCall {
            val pathRef = storageRef.child("images/users/${userId}")
            val ONE_MEGABYTE: Long = 1024 * 1024
            pathRef.getBytes(ONE_MEGABYTE).addOnSuccessListener {

            }

        }
    }*/

    override suspend fun deleteUserImage(userId: String): Unit = withContext(Dispatchers.IO) {
        safeCall {
            val pictureRef = storageRef.child("images/users/$userId")
            val deleteTask = pictureRef.delete().await()
            Resource.Success(deleteTask)
        }
    }
}

/*var file = Uri.fromFile(File("path/to/images/rivers.jpg"))
val riversRef = storageRef.child("images/${file.lastPathSegment}")
uploadTask = riversRef.putFile(file)

// Register observers to listen for when the download is done or if it fails
uploadTask.addOnFailureListener {
    // Handle unsuccessful uploads
}.addOnSuccessListener { taskSnapshot ->
    // taskSnapshot.metadata contains file metadata such as size, content-type, etc.
    // ...
}*/

