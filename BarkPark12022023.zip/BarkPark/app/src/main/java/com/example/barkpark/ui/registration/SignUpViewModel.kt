package com.example.barkpark.ui.registration

import android.util.Log
import android.util.Patterns
import androidx.lifecycle.*
import com.example.barkpark.model.User
import com.example.barkpark.repository.AuthRepository
import com.example.barkpark.util.Resource
import kotlinx.coroutines.launch

class SignUpViewModel(private val repository:AuthRepository) : ViewModel() {

    private val _userRegistrationStatus = MutableLiveData<Resource<User>>()
    val userRegistrationStatus: LiveData<Resource<User>> = _userRegistrationStatus


    fun createUser(email:String, password:String, username:String, phone:String) : String {
        var error = if(email.isEmpty() || username.isEmpty() || password.isEmpty() || phone.isEmpty())
            "Empty Strings"
        else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            "Not a valid email"
        }else "okay strings"
        error.let{
            _userRegistrationStatus.postValue(Resource.Error(it))
        }
        if (error != "okay strings") {
            Log.d("testString1",error)
        }
        else {
            _userRegistrationStatus.postValue(Resource.Loading())
            viewModelScope.launch {
                val registrationResult = repository.createUser(email, password, username, phone)
                _userRegistrationStatus.postValue(registrationResult)
                registrationResult.data.toString()?.let { Log.d("testString2", it) }
            }
        }
        return error
    }

    class RegisterViewModelFactory(private val repo: AuthRepository) : ViewModelProvider.NewInstanceFactory() {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SignUpViewModel(repo) as T
        }
    }
}