package com.example.barkpark.util

class Constants {

    companion object {
        const val BASE_URL = "https://dog.ceo/dog-api/documentation/random"
    }
}