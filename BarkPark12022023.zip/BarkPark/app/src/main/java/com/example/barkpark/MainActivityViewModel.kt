package com.example.barkpark

import androidx.lifecycle.ViewModel

class MainActivityViewModel : ViewModel() {


}