package com.example.barkpark.ui.userProfile

import androidx.lifecycle.*
import com.example.barkpark.model.User
import com.example.barkpark.repository.AuthRepository
import com.example.barkpark.repository.FirestoreRepository
import com.example.barkpark.util.Resource
import kotlinx.coroutines.launch
import com.example.barkpark.model.DogItem

class AddDogItemViewModel(private val authRep: AuthRepository, val FSRepository: FirestoreRepository) : ViewModel() {

    private val _currentUser = MutableLiveData<Resource<User>>()
    val currentUser: LiveData<Resource<User>> = _currentUser

    val _dogStatus : MutableLiveData<Resource<List<DogItem>>> = MutableLiveData()
    val dogStatus : LiveData<Resource<List<DogItem>>> = _dogStatus

    private val _addDogStatus = MutableLiveData<Resource<Void>>()
    val addDogStatus : LiveData<Resource<Void>> = _addDogStatus

    private val _deleteDogStatus =  MutableLiveData<Resource<Void>>()
    val deleteDogStatus : LiveData<Resource<Void>> = _deleteDogStatus

    init {
        FSRepository.getDogsLiveData(_dogStatus)
    }

    fun addDog(dog: DogItem) {
        viewModelScope.launch {
            authRep.getUid().data?.let { dog.OwnerId=it }
            if(dog.OwnerId=="")
                _addDogStatus.postValue(Resource.Error("Empty id"))
            else {
                _addDogStatus.postValue(Resource.Loading())
                _addDogStatus.postValue(FSRepository.addDog(dog))
            }
        }
    }

    class AddDogItemViewModelFactory(val authRepo:AuthRepository, val FSRepository: FirestoreRepository) : ViewModelProvider.NewInstanceFactory() {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddDogItemViewModel(authRepo, FSRepository) as T
        }
    }
}