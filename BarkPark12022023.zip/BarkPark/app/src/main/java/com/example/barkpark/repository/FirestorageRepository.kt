package com.example.barkpark.repository

import android.net.Uri
import com.example.barkpark.util.Resource
import com.google.firebase.storage.UploadTask

interface FirestorageRepository {

    suspend fun uploadUserImage(image: Uri?, userId: String) : Resource<UploadTask.TaskSnapshot>

    suspend fun uploadDogImage(image: String?, dogId: String) : Resource<UploadTask.TaskSnapshot>

    //suspend fun downloadUserImage() : Resource<String?>

    suspend fun deleteUserImage(userId: String)
}