package com.example.barkpark.ui.userProfile

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.barkpark.R
import com.example.barkpark.databinding.ProfileLayoutBinding
import com.example.barkpark.model.ItemManager
import com.example.barkpark.repository.firebasempl.AuthRepositoryFirebase
import com.example.barkpark.repository.firebasempl.FireStoreRepositoryFirebase
import com.example.barkpark.util.Resource
import com.example.barkpark.util.autoCleared

class ProfileFragment : Fragment() {

    private var binding : ProfileLayoutBinding by autoCleared()

    private val viewModel : ProfileViewModel by viewModels {
        ProfileViewModel.ProfileViewModelFactory(AuthRepositoryFirebase(), FireStoreRepositoryFirebase())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setHasOptionsMenu(true)

        binding = ProfileLayoutBinding.inflate(inflater, container, false)

        binding.profileEditBtn.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_editProfileFragment)
        }

        binding.addDogBtn.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_addDogItemFragment)
        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.dogsRecycler.adapter = ProfileAdapter(ItemManager.items, object : ProfileAdapter.DogListener {
            override fun onDogClicked(index: Int) {
                //Does nothing.
            }
            override fun onDogLongClicked(index: Int) {
                viewModel.deleteDog(ItemManager.items[index].Id)
                ItemManager.remove(index)
                binding.dogsRecycler.adapter!!.notifyItemRemoved(index)
            }
        })

        binding.dogsRecycler.layoutManager = LinearLayoutManager(requireContext())

        ItemTouchHelper(object : ItemTouchHelper.Callback() {

            override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            ) = makeFlag(ItemTouchHelper.ACTION_STATE_SWIPE, ItemTouchHelper.UP or ItemTouchHelper.DOWN)

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                TODO("Not yet implemented")
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                ItemManager.remove(viewHolder.adapterPosition)
                binding.dogsRecycler.adapter!!.notifyDataSetChanged()
            }
        }).attachToRecyclerView(binding.dogsRecycler)

        viewModel.currentUser.observe(viewLifecycleOwner) {

            when(it){
                is Resource.Loading -> {

                }
                is Resource.Success -> {
                    val newName = viewModel.currentUser.value?.data?.name
                    binding.usernameProfile.text = newName
                }
                is Resource.Error -> {

                }
            }
        }

        viewModel.dogStatus.observe(viewLifecycleOwner) {

            when(it){
                is Resource.Loading -> {

                }
                is Resource.Success -> {
                    Log.d("get dogs", viewModel.dogStatus.value?.data.toString()) //viewModel.dogStatus.value?.data has a list of all the dogs
                }                                                                     //need to use this block to call adapter and add dogs with the values in the dog status
                is Resource.Error -> {

                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.profile_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == R.id.action_sign_out){
            viewModel.signOut()
            findNavController().navigate(R.id.action_profileFragment_to_loginFragment)
        }

        return super.onOptionsItemSelected(item)
    }
}