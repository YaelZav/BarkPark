package com.example.barkpark.model


data class User(val name:String="",
                val email:String="",
                val phone:String?="",
                var id:String?="") {



    var userImage: String? = null
}
