package com.example.barkpark.ui.userProfile

import android.util.Log
import androidx.lifecycle.*
import com.example.barkpark.model.DogItem
import com.example.barkpark.model.User
import com.example.barkpark.repository.AuthRepository
import com.example.barkpark.repository.FirestoreRepository
import com.example.barkpark.util.Resource
import kotlinx.coroutines.launch

class ProfileViewModel(private val authRep:AuthRepository, val FSRepository: FirestoreRepository) : ViewModel() {

    private val _currentUser = MutableLiveData<Resource<User>>()
    val currentUser: LiveData<Resource<User>> = _currentUser

    val _dogStatus : MutableLiveData<Resource<List<DogItem>>> = MutableLiveData()
    val dogStatus : LiveData<Resource<List<DogItem>>> = _dogStatus

    private val _addDogStatus = MutableLiveData<Resource<Void>>()
    val addDogStatus : LiveData<Resource<Void>> = _addDogStatus

    private val _deleteDogStatus =  MutableLiveData<Resource<Void>>()
    val deleteDogStatus : LiveData<Resource<Void>> = _deleteDogStatus

    init {
        FSRepository.getDogsLiveData(_dogStatus)

        viewModelScope.launch {
            _currentUser.postValue(Resource.Loading())
            _currentUser.postValue(authRep.currentUser())
        }

        viewModelScope.launch {
            _dogStatus.postValue(Resource.Loading())
            _dogStatus.postValue(authRep.getUid().data?.let { FSRepository.getDogsByOwnerId(it) })
        }
    }

    fun signOut() {
        authRep.logOut()
    }

    fun deleteDog(dogId:String) {
        viewModelScope.launch {
            if(dogId.isEmpty())
                _deleteDogStatus.postValue(Resource.Error("Empty dog id"))
            else {
                _deleteDogStatus.postValue(Resource.Loading())
                _deleteDogStatus.postValue(FSRepository.deleteDog(dogId))
            }
        }
    }

    fun getDogs(ownerId: String) {
        viewModelScope.launch {
            if(ownerId.isEmpty())
                _dogStatus.postValue(Resource.Error("Empty dog id"))
            else {
                _dogStatus.postValue(Resource.Loading())
                _dogStatus.postValue(FSRepository.getDogsByOwnerId(ownerId))
            }
        }
    }

    class ProfileViewModelFactory(val authRepo:AuthRepository, val FSRepository: FirestoreRepository) : ViewModelProvider.NewInstanceFactory() {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ProfileViewModel(authRepo, FSRepository) as T
        }
    }
}