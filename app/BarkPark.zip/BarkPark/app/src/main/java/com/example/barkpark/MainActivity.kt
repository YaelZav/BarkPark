package com.example.barkpark

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*val dogHead = findViewById<ImageView>(R.id.dog_head)
        val alphaAnim = AnimationUtils.loadAnimation(applicationContext, R.anim.head_move)
        dogHead.startAnimation(alphaAnim)*/


    }
}